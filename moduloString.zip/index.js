//IMPORTANDO MÓDULOS
import {nome, olaPessoa, textoMaiusculas} from'./lib/strings.js'
//IMPORTAÇÃO DEFAULT
import textoMinusculas from'./lib/strings.js';


console.log(nome)

olaPessoa()
textoMaiusculas("morango")

textoMinusculas("Marinette")